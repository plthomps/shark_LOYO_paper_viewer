# Shark LOYO Paper Viewer

Streamlit viewer for the Cape Cod white shark Random Forest paper. Displays the saved LOYO 2017–2024 model metrics and full-test 2022 interpretability figures for ALL, DAWN, DAY, DUSK, and NIGHT.

## Deploy

1. Create a new GitHub repository named `shark-loyo-paper-viewer`.
2. Upload **the contents of this ZIP**, preserving `app.py`, `requirements.txt`, and the `results/` directory.
3. Open [Streamlit Community Cloud](https://share.streamlit.io/), choose **Create app**, select the repository, branch `main`, and entrypoint `app.py`.
4. Deploy. No secrets or API keys are needed.

## Data and provenance

Figures and numerical summaries are exported from the Model 17 LOYO overnight analysis. The 2022 PDP/SHAP figures use the full eligible held-out test fold as produced by that notebook. The viewer does not retrain or resample. Two-way PDP plots are descriptive joint response surfaces, not formal interaction significance tests.

This public-viewer package intentionally excludes original observation-level predictions, full SHAP observation rows, model joblib files, preprocessing objects, and source parquet data. Retain the full research archive privately for reproducibility. Review permissions and dataset licenses before publishing.

## Note on repository size

The bundle includes both PNG and PDF publication figures, and many interaction plots. GitHub web upload may have per-file and batch limits; for large folders, use GitHub Desktop to commit and push. For Streamlit Community Cloud, repository size and memory can affect deployment.
